#include <ArduinoIoTCloud.h>
#include <Arduino_ConnectionHandler.h>
#include <WiFi.h>  // Include this if using ESP32 or other WiFi-enabled board

// Replace with your actual WiFi credentials
const char SSID[] = "TM";  
const char PASS[] = "TM200513";  

// Function prototypes
void onTempChange();
void onLedChange();

// Variables for Arduino IoT Cloud
float temp;
bool led;

void initProperties() {
    ArduinoCloud.addProperty(temp, READWRITE, 30 * SECONDS, onTempChange);
    ArduinoCloud.addProperty(led, READWRITE, 30 * SECONDS, onLedChange);
}

// Create IoT Cloud connection
WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);
